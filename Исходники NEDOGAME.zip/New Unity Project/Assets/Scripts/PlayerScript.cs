﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour
{

    public float speed = 3f;
    public float powerOfJump = 15f;
    private Vector2 movement;
    private SpriteRenderer mySpriteRend = null;
    private Transform position = null;

    private void Awake()
    {
        mySpriteRend = GetComponent<SpriteRenderer>();
        position = GetComponent<Transform>();
    }

    void Update()
    {
        float inputX = Input.GetAxis("Horizontal");
        float inputY = Input.GetAxis("Vertical");

        movement = new Vector2(speed * inputX, inputY);

        
        if (Input.GetKeyDown(KeyCode.D))
        {
            mySpriteRend.flipX = false;
        }
        else if (Input.GetKeyDown(KeyCode.A))
        {
            mySpriteRend.flipX = true;
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            movement = Jump();
            FixedUpdate();
        }
    }

    void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().velocity = movement;
       
    }

    Vector2 Jump()
    {
        Vector2 vectorJump = new Vector2(position.localPosition.x, powerOfJump * speed * position.localPosition.y);
        return vectorJump;
    }
}
