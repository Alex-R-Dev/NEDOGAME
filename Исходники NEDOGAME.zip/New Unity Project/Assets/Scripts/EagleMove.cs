﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EagleMove : MonoBehaviour
{
    public float speedEagle = -3f;
    public float direction = -1f;

    private Vector2 movement;
    private SpriteRenderer mySpriteRend = null;
    //mySpriteRenderer = GetComponent<SpriteRenderer>();  
    
    private void Awake()
    {
        // get a reference to the SpriteRenderer component on this gameObject
        mySpriteRend = GetComponent<SpriteRenderer>();
    }
    void Update()
    {
        float inputX = Input.GetAxis("Horizontal");
        float inputY = Input.GetAxis("Vertical");
        if (inputX >= 4)
        {
            mySpriteRend.flipX = false;
            speedEagle *= direction;
        }
        if (inputX <= 2.2)
        {
            mySpriteRend.flipX = true;
            speedEagle *= direction;
        }
        movement = new Vector2(inputX * speedEagle, inputY);
    }

    void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().velocity = movement;
    }
}
